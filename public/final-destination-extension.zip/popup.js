document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("profileContainer");
  const addBtn = document.getElementById("addBtn");
  const statusEl = document.getElementById("status");
  const companyNameInput = document.getElementById("companyName");
  const positionTitleInput = document.getElementById("positionTitle");
  const companyUrlInput = document.getElementById("companyUrl");
  const jobUrlInput = document.getElementById("jobUrl");
  const jobDescriptionInput = document.getElementById("jobDescription");
  const profileIdInput = document.getElementById("profileId");
  const serverUrlInput = document.getElementById("serverUrl");
  const connectionDot = document.getElementById("connectionDot");
  const openBatchBtn = document.getElementById("openBatchBtn");
  const copyBtn = document.getElementById("copyBtn");
  const pasteBtn = document.getElementById("pasteBtn");

  let statusTimeout = null;
  let submission = null;
  let submitting = false;

  if (!container || !addBtn) {
    console.error("Required elements not found");
    return;
  }

  const hasStorage = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  const CLIPBOARD_STORAGE_KEY = "fd_clipboard";
  const SERVER_URL_KEY = "fd_server_url";

  // ======== Server URL Management ========

  function getBaseUrl() {
    const custom = serverUrlInput?.value?.trim().replace(/\/+$/, "");
    const url = new URL(custom || "https://final-destination-rose.vercel.app");
    if (!["http:", "https:"].includes(url.protocol))
      throw new Error("Enter an http:// or https:// app URL.");
    return url.origin;
  }

  async function appRequest(path, method = "GET", body) {
    const base = new URL(getBaseUrl());
    if (hasStorage) await chrome.storage.local.set({ [SERVER_URL_KEY]: base.origin });
    const tabs = await chrome.tabs.query({ url: `${base.origin}/*` });
    const app = tabs.find((tab) => tab.url?.startsWith(base.origin + "/"));
    if (!app?.id) throw new Error("Open your app in this browser first, then retry.");
    const result = await chrome.tabs.sendMessage(app.id, {
      type: "fd-app-request",
      path,
      method,
      body,
    });
    if (!result || !Number.isInteger(result.status))
      throw new Error("Reload the extension and refresh your app tab.");
    return {
      ok: result.status >= 200 && result.status < 300,
      status: result.status,
      json: async () => result.body,
    };
  }

  // Load saved server URL
  if (hasStorage && serverUrlInput) {
    try {
      const result = await chrome.storage.local.get(SERVER_URL_KEY);
      if (result[SERVER_URL_KEY]) {
        serverUrlInput.value = result[SERVER_URL_KEY];
      }
    } catch {}
  }

  // Save server URL on change
  if (serverUrlInput) {
    serverUrlInput.addEventListener("input", () => {
      if (hasStorage) {
        chrome.storage.local.set({ [SERVER_URL_KEY]: serverUrlInput.value.trim() });
      }
    });
  }

  // Check connection on load

  // ======== Copy/Paste ========

  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      const data = {
        companyName: companyNameInput.value.trim(),
        companyUrl: companyUrlInput.value.trim(),
      };
      if (!data.companyName && !data.companyUrl) {
        statusEl.textContent = "Nothing to copy";
        statusEl.className = "error";
        clearTimeout(statusTimeout);
        statusTimeout = setTimeout(() => {
          statusEl.textContent = "";
          statusEl.className = "";
        }, 1500);
        return;
      }
      if (hasStorage) {
        try {
          await chrome.storage.local.set({ [CLIPBOARD_STORAGE_KEY]: data });
          copyBtn.classList.add("success");
          statusEl.textContent = "✓ Copied!";
          statusEl.className = "success";
          clearTimeout(statusTimeout);
          statusTimeout = setTimeout(() => {
            copyBtn.classList.remove("success");
            statusEl.textContent = "";
            statusEl.className = "";
          }, 1500);
        } catch {
          statusEl.textContent = "Copy failed";
          statusEl.className = "error";
        }
      }
    });
  }

  if (pasteBtn) {
    pasteBtn.addEventListener("click", async () => {
      if (hasStorage) {
        try {
          const result = await chrome.storage.local.get(CLIPBOARD_STORAGE_KEY);
          const data = result[CLIPBOARD_STORAGE_KEY];
          if (data) {
            if (data.companyName) companyNameInput.value = data.companyName;
            if (data.companyUrl) companyUrlInput.value = data.companyUrl;
            saveFormData();
            pasteBtn.classList.add("success");
            statusEl.textContent = "✓ Pasted!";
            statusEl.className = "success";
            clearTimeout(statusTimeout);
            statusTimeout = setTimeout(() => {
              pasteBtn.classList.remove("success");
              statusEl.textContent = "";
              statusEl.className = "";
            }, 1500);
          } else {
            statusEl.textContent = "Nothing to paste";
            statusEl.className = "warning";
            clearTimeout(statusTimeout);
            statusTimeout = setTimeout(() => {
              statusEl.textContent = "";
              statusEl.className = "";
            }, 1500);
          }
        } catch {
          statusEl.textContent = "Paste failed";
          statusEl.className = "error";
        }
      }
    });
  }

  // ======== Tab Info ========

  let tab = null;
  try {
    if (typeof chrome !== "undefined" && chrome.tabs) {
      const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      tab = currentTab;
    }
  } catch {}

  const tabUrl = tab?.url || "default";
  const storageKey = `form_data_${encodeURIComponent(tabUrl)}`;

  // ======== Restore Saved Form Data ========

  if (hasStorage) {
    try {
      const result = await chrome.storage.local.get(storageKey);
      const savedData = result[storageKey];
      if (savedData) {
        submission = savedData.submission || null;
        if (savedData.companyName) companyNameInput.value = savedData.companyName;
        if (savedData.positionTitle) positionTitleInput.value = savedData.positionTitle;
        if (savedData.companyUrl) companyUrlInput.value = savedData.companyUrl;
        if (savedData.jobUrl) jobUrlInput.value = savedData.jobUrl;
        if (savedData.jobDescription) jobDescriptionInput.value = savedData.jobDescription;
        if (savedData.profileId) profileIdInput.value = savedData.profileId;
        if (savedData.includeCoverLetter !== undefined) {
          document.getElementById("includeCoverLetter").checked = savedData.includeCoverLetter;
        }
        statusEl.textContent = "Restored saved data";
        statusEl.className = "";
      }
    } catch {}
  }

  // Set job URL from tab
  if (!jobUrlInput.value && tab?.url) {
    jobUrlInput.value = tab.url;
  }

  // Auto-extract position title from tab title
  if (!positionTitleInput.value && tab?.title) {
    let title = tab.title;
    title = title.replace(
      /\s*[-|·•]\s*(LinkedIn|Indeed|Glassdoor|ZipRecruiter|Monster|Dice|Hired|AngelList|Wellfound|Lever|Greenhouse|Workday|Careers|Jobs).*$/i,
      "",
    );
    title = title.replace(/\s*[-|·•]\s*(Apply|Application|Job Posting|Job Description).*$/i, "");
    positionTitleInput.value = title.trim();
  }

  // ======== Company Website Extraction ========

  const extractCompanyWebsite = (jobUrl) => {
    try {
      const url = new URL(jobUrl);
      const hostname = url.hostname.toLowerCase();

      const atsPatterns = [
        { domain: "greenhouse.io", pathPattern: /^\/([^/]+)/ },
        { domain: "lever.co", pathPattern: /^\/([^/]+)/ },
        { domain: "ashbyhq.com", pathPattern: /^\/([^/]+)/ },
        { domain: "jobs.lever.co", subdomainCompany: true },
        { domain: "boards.greenhouse.io", pathPattern: /^\/([^/]+)/ },
        { domain: "myworkdayjobs.com", subdomainCompany: true },
      ];

      for (const pattern of atsPatterns) {
        if (hostname.includes(pattern.domain)) {
          if (pattern.subdomainCompany) {
            const subdomain = hostname.split(".")[0];
            if (
              subdomain &&
              subdomain !== "www" &&
              subdomain !== "jobs" &&
              subdomain !== "careers"
            ) {
              return `https://www.${subdomain}.com`;
            }
          } else if (pattern.pathPattern) {
            const match = url.pathname.match(pattern.pathPattern);
            if (match && match[1]) {
              return `https://www.${match[1]}.com`;
            }
          }
        }
      }

      const jobBoards = [
        "linkedin.com",
        "indeed.com",
        "glassdoor.com",
        "ziprecruiter.com",
        "monster.com",
        "dice.com",
      ];
      if (jobBoards.some((board) => hostname.includes(board))) {
        return "";
      }

      const cleanHostname = hostname.replace(
        /^(www\.|careers\.|jobs\.|apply\.|hire\.|recruiting\.)/,
        "",
      );
      return `https://www.${cleanHostname}`;
    } catch {
      return "";
    }
  };

  // ======== Save Form Data ========

  const saveFormData = () => {
    if (!hasStorage) return;
    const data = {
      companyName: companyNameInput.value,
      positionTitle: positionTitleInput.value,
      companyUrl: companyUrlInput.value,
      jobUrl: jobUrlInput.value,
      jobDescription: jobDescriptionInput.value,
      profileId: profileIdInput.value,
      includeCoverLetter: document.getElementById("includeCoverLetter").checked,
      submission,
    };
    chrome.storage.local.set({ [storageKey]: data }).catch(() => {});
  };

  document.querySelectorAll("input, textarea, input[type='checkbox']").forEach((el) => {
    const eventType = el.type === "checkbox" ? "change" : "input";
    el.addEventListener(eventType, () => {
      if (el.type !== "checkbox") el.style.borderColor = "#E5E5E5";
      saveFormData();
    });
  });

  // ======== Load Profiles ========

  let profiles = [];
  let profileRequest = 0;

  const loadProfiles = async () => {
    const version = ++profileRequest;
    profiles = [];
    container.innerHTML = '<span style="font-size:11px;color:#999;">Loading profiles...</span>';

    try {
      const res = await appRequest("/api/profiles");
      if (version !== profileRequest) return;
      if (res.ok) {
        profiles = await res.json();
        if (!Array.isArray(profiles)) throw new Error("Invalid profiles response");
        connectionDot.className = "dot online";
        container.innerHTML = "";
        profileIdInput.value = "kirtan";
        container.textContent = "Kirtan Thummar · automatic template";
      } else {
        connectionDot.className = "dot offline";
        profiles = [];
        profileIdInput.value = "";
        container.textContent = "App tab unavailable";
      }
    } catch {
      if (version !== profileRequest) return;
      profiles = [];
      connectionDot.className = "dot offline";
      container.innerHTML =
        '<span style="font-size:11px;color:#999;">Open the app in this browser</span>';
    }
  };

  await loadProfiles();
  serverUrlInput?.addEventListener("change", () => {
    profileIdInput.value = "";
    void loadProfiles();
  });

  // ======== Auto-extract from URL ========

  const isInternalUrl = (url) => {
    if (!url) return true;
    return (
      url.startsWith("chrome://") ||
      url.startsWith("chrome-extension://") ||
      url.startsWith("edge://") ||
      url.startsWith("extension://") ||
      url.startsWith("about:")
    );
  };

  const hasScripting = typeof chrome !== "undefined" && chrome.scripting;

  // Try to extract company from page content first
  if (!companyNameInput.value && tab?.id && tab?.url && !isInternalUrl(tab.url) && hasScripting) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: () => {
          const meta =
            document.querySelector('meta[property="og:site_name"]') ||
            document.querySelector('meta[name="application-name"]');
          const ld = document.querySelector('script[type="application/ld+json"]');
          if (ld) {
            try {
              const p = JSON.parse(ld.textContent);
              if (p.name) return p.name;
              if (p.publisher?.name) return p.publisher.name;
            } catch {}
          }
          return meta?.content || "";
        },
      });
      if (results && results[0]?.result) {
        companyNameInput.value = results[0].result;
        saveFormData();
      }
    } catch {}
  }

  if (!companyNameInput.value || !companyUrlInput.value) {
    try {
      const jobUrl = tab?.url || "";
      const hostname = new URL(jobUrl).hostname;
      const parts = hostname.replace(/^(www\.|careers\.|jobs\.|apply\.|hire\.)/, "").split(".");
      if (parts.length >= 1) {
        const main = parts[0];
        if (!companyNameInput.value) {
          companyNameInput.value = main.charAt(0).toUpperCase() + main.slice(1);
          saveFormData();
        }
        if (!companyUrlInput.value) {
          const extractedWebsite = extractCompanyWebsite(jobUrl);
          if (extractedWebsite) {
            companyUrlInput.value = extractedWebsite;
          } else {
            companyUrlInput.value = `https://www.${parts.join(".")}`;
          }
          saveFormData();
        }
      }
    } catch {}
  }

  // ======== Extract text selection from page ========

  if (
    !jobDescriptionInput.value &&
    tab?.id &&
    tab?.url &&
    !isInternalUrl(tab.url) &&
    hasScripting
  ) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: () => window.getSelection().toString() || "",
      });
      if (results && results[0]?.result) {
        jobDescriptionInput.value = results[0].result;
        saveFormData();
      }
    } catch {}
  }

  // ======== Open Batch Mode ========

  if (openBatchBtn) {
    openBatchBtn.addEventListener("click", () => {
      const base = getBaseUrl();
      window.open(`${base}/batch`, "_blank");
    });
  }

  // ======== Add to Queue ========

  addBtn.addEventListener("click", async () => {
    if (submitting) return;
    const selectedProfileId = "kirtan";
    const selectedProfile = { name: "Kirtan Thummar", color: "from-blue-500 to-blue-600" };

    const job = {
      companyName: companyNameInput.value.trim(),
      positionTitle: positionTitleInput.value.trim(),
      companyUrl: jobUrlInput.value.trim(),
      jobDescription: jobDescriptionInput.value.trim(),
      personalDetails: document.getElementById("personalDetails")?.value?.trim() || "",
      profileId: selectedProfileId || undefined,
      profileName: selectedProfile ? selectedProfile.name : undefined,
      profileColor: selectedProfile ? selectedProfile.color : undefined,
      companyWebsite: companyUrlInput.value.trim(),
      includeCoverLetter: document.getElementById("includeCoverLetter").checked,
    };

    let hasErrors = false;
    statusEl.textContent = "";
    statusEl.className = "";

    companyNameInput.style.borderColor = "#E5E5E5";
    positionTitleInput.style.borderColor = "#E5E5E5";
    jobUrlInput.style.borderColor = "#E5E5E5";
    jobDescriptionInput.style.borderColor = "#E5E5E5";
    container.style.border = "";

    if (!job.companyName) {
      companyNameInput.style.borderColor = "#ef4444";
      hasErrors = true;
    }
    if (!job.positionTitle) {
      positionTitleInput.style.borderColor = "#ef4444";
      hasErrors = true;
    }
    if (!job.companyUrl) {
      jobUrlInput.style.borderColor = "#ef4444";
      hasErrors = true;
    }
    if (!job.jobDescription) {
      jobDescriptionInput.style.borderColor = "#ef4444";
      hasErrors = true;
    }

    if (hasErrors) {
      if (!statusEl.textContent) {
        statusEl.textContent = "Fill all fields";
        statusEl.className = "error";
      }
      return;
    }

    addBtn.disabled = true;
    submitting = true;
    addBtn.textContent = "Adding...";
    statusEl.textContent = "";

    try {
      const fingerprint = JSON.stringify(job);
      if (!submission || submission.fingerprint !== fingerprint)
        submission = { id: crypto.randomUUID(), fingerprint };
      if (hasStorage)
        await chrome.storage.local.set({
          [storageKey]: {
            companyName: companyNameInput.value,
            positionTitle: positionTitleInput.value,
            companyUrl: companyUrlInput.value,
            jobUrl: jobUrlInput.value,
            jobDescription: jobDescriptionInput.value,
            profileId: selectedProfileId,
            includeCoverLetter: job.includeCoverLetter,
            submission,
          },
        });
      const response = await appRequest("/api/queue", "POST", { ...job, id: submission.id });

      if (response.ok) {
        if (hasStorage) {
          await chrome.storage.local.remove(storageKey).catch(() => {});
        }
        statusEl.textContent = "✓ Saved to queue. Open the queue to process or view this job.";
        addBtn.textContent = "Saved to queue";
        statusEl.className = "success";
        clearTimeout(statusTimeout);
      } else {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || `Server error (${response.status})`);
      }
    } catch (e) {
      console.error(e);
      statusEl.textContent = "Error: " + (e.message || "Connection failed");
      statusEl.className = "error";
      addBtn.disabled = false;
      submitting = false;
      addBtn.textContent = "Add to Queue";
    }
  });
});
